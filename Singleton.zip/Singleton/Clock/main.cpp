#include "Clock.h"
#include <iostream>

int main() {
	//Clock clk ;
	std::cout << Clock::GetTimeString() << std::endl ;
}
